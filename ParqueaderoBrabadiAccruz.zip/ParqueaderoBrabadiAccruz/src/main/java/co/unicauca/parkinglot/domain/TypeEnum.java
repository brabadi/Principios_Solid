/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicauca.parkinglot.domain;

/**
 * Tipos de Vehiculo
 *
 * @authores Astrid Carolina Cruz(accruz@unicauca.edu.co) 
 * Braian Alexis Bastidas(brabadi@unicauca.edu.co)
 * 
 * Se crean los tres tipos de vehiculos (Moto,Carro y Camion)
 */
public enum TypeEnum {
    MOTO, CAR, TRUCK ;
    
}
